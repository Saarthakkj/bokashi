In Dataset_split:
	train/val/test_with_labels_2classes.csv are train/validation/test split of the dataset along with the privacy annotations(private/public).
	train/val/test_split_1_labels_only.csv are train/validation/test split of the dataset along with only the binary labels(0/1). Data are following the same order of "_with_labels_2classes.csv" files.
In ImFiles:
	url of Image files.
In ImgTags:
	ut/dt/utdt are user tags only, deep tags only, the concatenation of user tags and deep tags.
	dt_plus_ut_train1_2.tsv:
		1st col: indices
		2nd col: binary privacy labels
		3rd col: image IDs
		4th col: image tags

